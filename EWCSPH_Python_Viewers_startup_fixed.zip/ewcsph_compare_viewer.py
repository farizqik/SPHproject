"""Synchronized multi-case EWCSPH comparison — run: python ewcsph_compare_viewer.py"""
from __future__ import annotations
import argparse
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
from matplotlib.figure import Figure
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from ewcsph_core import Case,FIELD_NAMES
from ewcsph_gui import MultiFolderDialog,add_figure,draw_field,folder_information

class CompareViewer:
    def __init__(self,root,folders):
        self.root=root;self.root.title('EWCSPH — Multi-Case Comparison');root.geometry('1450x920')
        self.cases=[Case(folder) for folder in folders]
        self.time_start=max(c.times[0] for c in self.cases)
        self.time_end=min(c.times[-1] for c in self.cases)
        if self.time_end<self.time_start:raise ValueError('Cases have no common saved time interval')
        self.times=np.arange(np.ceil(self.time_start*10-1e-9),np.floor(self.time_end*10+1e-9)+1)*.1
        if not len(self.times):self.times=np.array([self.time_start])
        self.times=self.times[:1201]
        self.i=0;self.playing=False;self.after_id=None
        self.field=tk.StringVar(value='vorticity');self.psi=tk.BooleanVar(value=True)
        self.near=tk.BooleanVar(value=True);self.spacing=tk.StringVar(value='0.06')
        self.source=tk.StringVar(value='velocity');self.fps=tk.StringVar(value='10')
        self.layout=tk.StringVar(value='Auto');self.show_wall=tk.BooleanVar(value=True)
        self.xmin=tk.StringVar(value='-10');self.xmax=tk.StringVar(value='10')
        self.ymin=tk.StringVar(value='-1.3');self.ymax=tk.StringVar(value='1.3')
        self.limits={}
        menus=tk.Menu(root);root.configure(menu=menus)
        filemenu=tk.Menu(menus,tearoff=False);menus.add_cascade(label='File',menu=filemenu)
        filemenu.add_command(label='Export PNG',command=self.save_png)
        filemenu.add_command(label='Export MP4 (requires ffmpeg)',command=self.save_mp4)
        menus.add_command(label='Show full folder names',command=lambda:folder_information(root,[c.folder for c in self.cases]))
        top=ttk.Frame(root,padding=6);top.pack(fill='x')
        ttk.Label(top,text='Field').pack(side='left')
        ttk.Combobox(top,textvariable=self.field,values=list(FIELD_NAMES),state='readonly',width=15).pack(side='left',padx=3)
        ttk.Checkbutton(top,text='Streamfunction contours',variable=self.psi,command=self.draw).pack(side='left',padx=8)
        ttk.Label(top,text='Δψ/(U∞D)').pack(side='left')
        ent=ttk.Entry(top,textvariable=self.spacing,width=8);ent.pack(side='left',padx=4)
        ent.bind('<Return>',lambda e:self.draw())
        ttk.Checkbutton(top,text='Near-zero levels',variable=self.near,command=self.draw).pack(side='left',padx=5)
        ttk.Label(top,text='ω source').pack(side='left',padx=3)
        ttk.Combobox(top,textvariable=self.source,values=['velocity','solver'],state='readonly',width=9).pack(side='left')
        ttk.Checkbutton(top,text='Cylinder',variable=self.show_wall,command=self.draw).pack(side='left',padx=6)
        ttk.Label(top,text='Layout').pack(side='left')
        ttk.Combobox(top,textvariable=self.layout,values=['Auto','Column','Row','Grid'],state='readonly',width=9).pack(side='left',padx=4)
        ttk.Button(top,text='Folder key',command=lambda:folder_information(root,[c.folder for c in self.cases])).pack(side='right')
        nav=ttk.Frame(root,padding=5);nav.pack(fill='x')
        for text,act in [('|<',lambda:self.set_frame(0)),('<',lambda:self.set_frame(self.i-1))]:
            ttk.Button(nav,text=text,command=act).pack(side='left')
        self.playbtn=ttk.Button(nav,text='Play',command=self.toggle);self.playbtn.pack(side='left',padx=5)
        for text,act in [('>',lambda:self.set_frame(self.i+1)),('>|',lambda:self.set_frame(len(self.times)-1))]:
            ttk.Button(nav,text=text,command=act).pack(side='left')
        self.slider=tk.Scale(nav,from_=0,to=len(self.times)-1,orient='horizontal',showvalue=False,
                             command=lambda x:self.set_frame(int(float(x)),from_slider=True))
        self.slider.pack(side='left',fill='x',expand=True,padx=12)
        ttk.Label(nav,text='FPS').pack(side='left');ttk.Entry(nav,textvariable=self.fps,width=5).pack(side='left',padx=5)
        self.status=ttk.Label(nav,text='');self.status.pack(side='left',padx=8)
        limbar=ttk.Frame(root,padding=4);limbar.pack(fill='x')
        for tag,var in [('x min',self.xmin),('x max',self.xmax),('y min',self.ymin),('y max',self.ymax)]:
            ttk.Label(limbar,text=tag).pack(side='left',padx=(7,2))
            ttk.Entry(limbar,textvariable=var,width=8).pack(side='left')
        ttk.Button(limbar,text='Apply view',command=self.draw).pack(side='left',padx=9)
        ttk.Button(limbar,text='Save PNG',command=self.save_png).pack(side='right')
        body=ttk.Frame(root);body.pack(fill='both',expand=True)
        self.fig=Figure(figsize=(12,7),dpi=100)
        _,self.canvas=add_figure(body,self.fig)
        self.field.trace_add('write',lambda *_:self.draw())
        self.layout.trace_add('write',lambda *_:self.draw())
        self.source.trace_add('write',lambda *_:self.draw())
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.draw()
    def set_frame(self,i,from_slider=False):
        self.i=int(np.clip(i,0,len(self.times)-1))
        if not from_slider:self.slider.set(self.i)
        self.draw()
    def toggle(self):
        self.playing=not self.playing
        self.playbtn.config(text='Pause' if self.playing else 'Play')
        if self.playing:self.step()
        elif self.after_id is not None:self.root.after_cancel(self.after_id);self.after_id=None
    def step(self):
        if not self.playing:return
        if self.i>=len(self.times)-1:self.playing=False;self.playbtn.config(text='Play');return
        self.set_frame(self.i+1)
        try:delay=max(30,int(1000/float(self.fps.get())))
        except ValueError:delay=100
        self.after_id=self.root.after(delay,self.step)
    def close(self):
        self.playing=False
        if self.after_id is not None:self.root.after_cancel(self.after_id)
        self.root.destroy()
    def draw(self):
        if not hasattr(self,'canvas'):return
        t=self.times[self.i];field=self.field.get();n=len(self.cases)
        self.status.config(text=f'Time {t:.4g} s | {self.i+1}/{len(self.times)} | {n} cases')
        try:
            if field not in self.limits:
                all_lims=[c.initial_stats(field) for c in self.cases]
                self.limits[field]=(min(x[0] for x in all_lims),max(x[1] for x in all_lims))
                if field=='vorticity':
                    maximum=max(abs(x) for x in self.limits[field]);self.limits[field]=(-maximum,maximum)
            lim=self.limits[field];step=float(self.spacing.get())
            if step<=0:raise ValueError('Contour spacing must be greater than zero')
            xv=(float(self.xmin.get()),float(self.xmax.get()))
            yv=(float(self.ymin.get()),float(self.ymax.get()))
            if xv[0]>=xv[1] or yv[0]>=yv[1]:raise ValueError('Invalid view limits')
            layout=self.layout.get();asp=(xv[1]-xv[0])/(yv[1]-yv[0])
            if layout=='Row' or (layout=='Auto' and asp<.77):nr,nc=1,n
            elif layout=='Grid' or (layout=='Auto' and .77<=asp<=1.3):nc=int(np.ceil(np.sqrt(n)));nr=int(np.ceil(n/nc))
            else:nr,nc=n,1
            self.fig.clear()
            axes=self.fig.subplots(nr,nc,squeeze=False)
            for j,c in enumerate(self.cases):
                ax=axes[j//nc,j%nc];ii=c.nearest(t)
                draw_field(ax,c,ii,field,self.psi.get(),step,self.near.get(),self.source.get(),lim,self.show_wall.get())
                ax.set_xlim(xv);ax.set_ylim(yv)
                ax.set_title(f'Panel {j+1}: Re={c.Re:g} | t={c.times[ii]:.4g} s | h/Δp={c.hdp:g}',fontsize=10)
            for j in range(n,nr*nc):axes[j//nc,j%nc].set_visible(False)
            cmap='RdBu_r' if field=='vorticity' else 'turbo'
            self.fig.colorbar(ScalarMappable(norm=Normalize(*lim),cmap=cmap),ax=axes.ravel().tolist(),label=FIELD_NAMES[field],fraction=.019,pad=.025)
            self.fig.subplots_adjust(left=.065,right=.90,top=.95,bottom=.07,hspace=.33,wspace=.24)
            self.canvas.draw_idle()
        except Exception as e:messagebox.showerror('Plot error',f'{type(e).__name__}: {e}',parent=self.root)
    def save_png(self):
        filename=filedialog.asksaveasfilename(parent=self.root,title='Export comparison figure',defaultextension='.png',filetypes=[('PNG','*.png')])
        if filename:self.fig.savefig(filename,dpi=180)
    def save_mp4(self):
        filename=filedialog.asksaveasfilename(parent=self.root,title='Export synchronized MP4',defaultextension='.mp4',filetypes=[('MP4','*.mp4')])
        if not filename:return
        try:
            from matplotlib.animation import FFMpegWriter
            writer=FFMpegWriter(fps=10,metadata={'title':'EWCSPH comparison'})
            previous=self.i
            with writer.saving(self.fig,filename,dpi=110):
                for i in range(len(self.times)):
                    self.i=i;self.draw();self.canvas.draw();writer.grab_frame()
                    self.root.update_idletasks()
            self.i=previous;self.draw()
            messagebox.showinfo('Export complete',filename,parent=self.root)
        except Exception as e:messagebox.showerror('MP4 export failed',f'{e}\nInstall ffmpeg and ensure it is on PATH.',parent=self.root)

def main():
    """Robust startup: make folder chooser visible and report errors."""
    import sys
    import traceback
    from tkinter import messagebox
    parser = argparse.ArgumentParser()
    parser.add_argument("folders", nargs="*")
    args, _ = parser.parse_known_args()
    print("[EWCSPH] Starting viewer...", flush=True)
    root = None
    try:
        root = tk.Tk()
        root.title("EWCSPH - Choose simulation results")
        root.geometry("540x100")
        root.lift()
        root.attributes("-topmost", True)
        root.update()
        root.after(500, lambda: root.attributes("-topmost", False) if root.winfo_exists() else None)
        if args.folders:
            folders = args.folders
        else:
            print("[EWCSPH] Opening multi-folder picker. Check Alt+Tab if necessary.", flush=True)
            dialog = MultiFolderDialog(root)
            folders = dialog.result
        if not folders:
            print("[EWCSPH] No folders selected; viewer closed.", flush=True)
            root.destroy()
            return
        print("[EWCSPH] Loading folders: " + ", ".join(map(str, folders)), flush=True)
        root.deiconify()
        CompareViewer(root, folders)
        root.lift()
        root.mainloop()
    except Exception:
        details = traceback.format_exc()
        print("[EWCSPH] STARTUP ERROR:\n" + details, file=sys.stderr, flush=True)
        try:
            if root is not None and root.winfo_exists():
                root.deiconify()
                messagebox.showerror("EWCSPH startup error", details[-4500:], parent=root)
                root.destroy()
        except Exception:
            pass
        raise

if __name__ == "__main__":
    main()

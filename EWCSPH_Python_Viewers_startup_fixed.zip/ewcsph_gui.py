"""Reusable Tk/Matplotlib widgets for EWCSPH Python viewers."""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from ewcsph_core import FIELD_NAMES

FIELDS=list(FIELD_NAMES)

def folder_information(root,folders):
    dlg=tk.Toplevel(root);dlg.title('EWCSPH — Full simulation folder paths');dlg.geometry('900x290')
    ttk.Label(dlg,text='Full simulation folder paths (select and copy):').pack(anchor='w',padx=12,pady=(12,5))
    txt=tk.Text(dlg,wrap='none',height=9)
    txt.pack(fill='both',expand=True,padx=12)
    txt.insert('1.0','\n'.join(f'{i+1}. {Path(f).resolve()}' for i,f in enumerate(folders)))
    txt.configure(state='normal')
    def copy():
        dlg.clipboard_clear();dlg.clipboard_append('\n'.join(str(Path(f).resolve()) for f in folders))
    controls=ttk.Frame(dlg);controls.pack(fill='x',padx=12,pady=8)
    ttk.Button(controls,text='Copy paths',command=copy).pack(side='left')
    ttk.Button(controls,text='Hide',command=dlg.withdraw).pack(side='right')
    return dlg

def levels_for(psi,spacing=0.06,near=True):
    if spacing<=0: raise ValueError('Streamfunction spacing must be positive')
    finite=psi[np.isfinite(psi)]
    if finite.size==0:return np.array([])
    mn,mx=finite.min(),finite.max()
    n=min(500,int(np.ceil(max(abs(mn),abs(mx))/spacing))+1)
    lev=np.arange(-n,n+1)*spacing
    if near:
        extra=np.array([.0005,.001,.002,.004,.008,.015,.03,.05])
        lev=np.unique(np.r_[lev,-extra,extra])
    return lev[(lev>=mn)&(lev<=mx)]

def draw_field(ax,case,index,field='vorticity',show_stream=True,spacing=.06,
               near_levels=True,source='velocity',limits=None,show_wall=True):
    ax.clear()
    z=case.polar(case.values(index,field))
    # Explicit triangles keep the annular topology (including the periodic seam).
    # Unlike pcolormesh on non-monotone polar X/Y, this avoids guessed cell edges.
    if not hasattr(case,'triangles'):
        jj=np.arange(case.nr-1)
        kk=np.arange(case.nt)
        here=(kk[:,None]*case.nr+jj[None,:]).ravel()
        nxt=(((kk+1)%case.nt)[:,None]*case.nr+jj[None,:]).ravel()
        case.triangles=np.vstack([np.column_stack([here,here+1,nxt]),
                                  np.column_stack([here+1,nxt+1,nxt])])
    kwargs={'shading':'gouraud','cmap':('RdBu_r' if field=='vorticity' else 'turbo'),
            'rasterized':True}
    if limits is not None:kwargs.update(vmin=limits[0],vmax=limits[1])
    mesh=ax.tripcolor(case.X.ravel(),case.Y.ravel(),z.ravel(),
                      triangles=case.triangles,**kwargs)
    if show_stream and case.has_wall:
        psi=case.streamfunction(index,source)
        if psi is not None:
            XX,YY,PP=case.contour_geometry(psi)
            lev=levels_for(PP,spacing,near_levels)
            if len(lev)>1:
                ax.contour(XX,YY,PP,levels=lev,colors='black',linewidths=.55)
    if show_wall and len(case.wall):
        # Solid, precisely located cylinder rather than oversized wall markers.
        from matplotlib.patches import Circle
        ax.add_patch(Circle((0,0),case.wall_r,facecolor='#292d34',edgecolor='black',linewidth=.4,zorder=8))
    ax.set_aspect('equal',adjustable='box');ax.set_xlabel('x/D');ax.set_ylabel('y/D')
    ax.grid(False)
    return mesh

def add_figure(parent,fig=None,toolbar=True):
    fig=fig if fig is not None else Figure(figsize=(10,5),dpi=95)
    canvas=FigureCanvasTkAgg(fig,master=parent)
    canvas.get_tk_widget().pack(fill='both',expand=True)
    if toolbar:
        bar=NavigationToolbar2Tk(canvas,parent,pack_toolbar=False)
        bar.update();bar.pack(side='bottom',fill='x')
    return fig,canvas

class MultiFolderDialog(tk.Toplevel):
    """Direct multi-directory browser with Ctrl/Shift selection, plus an Add queue.
    Unlike OS file pickers, lets user select multiple DIRECTORIES, even on
    platforms where the native directory picker is single-select only.
    """
    def __init__(self,parent):
        super().__init__(parent);self.title('Select EWCSPH result folders (Ctrl / Shift)')
        self.geometry('870x590');self.transient(parent);self.result=[]
        self.current=Path.home();self.queued=[]
        top=ttk.Frame(self);top.pack(fill='x',padx=10,pady=10)
        ttk.Label(top,text='Folder:').pack(side='left')
        self.path_var=tk.StringVar(value=str(self.current))
        entry=ttk.Entry(top,textvariable=self.path_var);entry.pack(side='left',expand=True,fill='x',padx=8)
        entry.bind('<Return>',lambda e:self.go())
        ttk.Button(top,text='Go',command=self.go).pack(side='left')
        ttk.Button(top,text='Up',command=lambda:self.enter(self.current.parent)).pack(side='left',padx=4)
        ttk.Button(top,text='Browse…',command=self.pick).pack(side='left')
        ttk.Label(self,text='Select result directories with Ctrl/Shift. Double-click to enter a directory.').pack(anchor='w',padx=12)
        frm=ttk.Frame(self);frm.pack(fill='both',expand=True,padx=10,pady=5)
        self.box=tk.Listbox(frm,selectmode=tk.EXTENDED,exportselection=False,font=('Segoe UI',10))
        scroll=ttk.Scrollbar(frm,orient='vertical',command=self.box.yview)
        self.box.configure(yscrollcommand=scroll.set)
        self.box.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        self.box.bind('<Double-Button-1>',self.open_selected)
        ttk.Label(self,text='Selected / added folders:').pack(anchor='w',padx=12)
        self.chosen=tk.Listbox(self,height=4,font=('Segoe UI',9));self.chosen.pack(fill='x',padx=10,pady=4)
        bottom=ttk.Frame(self);bottom.pack(fill='x',padx=10,pady=9)
        ttk.Button(bottom,text='Add selected',command=self.add).pack(side='left')
        ttk.Button(bottom,text='Remove queued',command=self.remove).pack(side='left',padx=6)
        ttk.Button(bottom,text='Use selected / added folders',command=self.confirm).pack(side='right')
        ttk.Button(bottom,text='Cancel',command=self.destroy).pack(side='right',padx=8)
        self.entries=[];self.enter(self.current)
        self.grab_set();self.wait_window(self)

    def pick(self):
        folder=filedialog.askdirectory(parent=self,title='Navigate to folder',initialdir=str(self.current))
        if folder:self.enter(Path(folder))
    def go(self):self.enter(Path(self.path_var.get()).expanduser())
    def enter(self,p):
        p=Path(p)
        if not p.is_dir():messagebox.showerror('Folder not found',str(p),parent=self);return
        try:items=sorted((f for f in p.iterdir() if f.is_dir()),key=lambda x:x.name.casefold())
        except PermissionError:items=[]
        self.current=p;self.path_var.set(str(p));self.entries=items;self.box.delete(0,'end')
        for item in items:
            mark='[RESULT] ' if (item/'SimulationConstants.csv').is_file() else '         '
            self.box.insert('end',mark+item.name)
    def open_selected(self,event=None):
        ind=self.box.curselection()
        if ind:self.enter(self.entries[ind[0]])
    def add(self):
        selection=[self.entries[i] for i in self.box.curselection()]
        if not selection and (self.current/'SimulationConstants.csv').is_file():selection=[self.current]
        invalid=[p for p in selection if not (p/'SimulationConstants.csv').is_file()]
        for p in selection:
            if p not in invalid and p not in self.queued:self.queued.append(p)
        self.chosen.delete(0,'end')
        for p in self.queued:self.chosen.insert('end',str(p))
        if invalid:messagebox.showwarning('Not a result folder',f'{len(invalid)} folder(s) lack SimulationConstants.csv.',parent=self)
    def remove(self):
        idx=set(self.chosen.curselection());self.queued=[p for i,p in enumerate(self.queued) if i not in idx]
        self.chosen.delete(0,'end')
        for p in self.queued:self.chosen.insert('end',str(p))
    def confirm(self):
        self.add()
        if not self.queued:messagebox.showinfo('Select folders','Select one or more result folders.',parent=self);return
        self.result=list(self.queued);self.destroy()

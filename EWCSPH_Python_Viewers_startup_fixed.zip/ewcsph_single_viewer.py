"""Interactive single-case EWCSPH Python viewer — run: python ewcsph_single_viewer.py"""
from __future__ import annotations
import argparse
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
import numpy as np
from matplotlib.figure import Figure
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from ewcsph_core import Case,FIELD_NAMES
from ewcsph_gui import add_figure,draw_field,folder_information

class SingleViewer:
    def __init__(self,root,folder):
        self.root=root;self.case=Case(folder);self.i=0;self.playing=False;self.after_id=None
        self.root.title('EWCSPH — Single Simulation Viewer');self.root.geometry('1350x850')
        self.field=tk.StringVar(value='velocity');self.psi=tk.BooleanVar(value=True)
        self.spacing=tk.StringVar(value='0.06');self.source=tk.StringVar(value='velocity')
        self.near=tk.BooleanVar(value=True);self.fps=tk.StringVar(value='12')
        self.show_wall=tk.BooleanVar(value=True)
        self.profile_angle=tk.StringVar(value='90');self.profile_field=tk.StringVar(value='velocity')
        self.line_points=[];self.line_active=False
        self.limits={}
        top=ttk.Frame(root,padding=6);top.pack(fill='x')
        ttk.Label(top,text='Field').pack(side='left')
        ttk.Combobox(top,textvariable=self.field,values=list(FIELD_NAMES),width=13,state='readonly').pack(side='left',padx=3)
        ttk.Checkbutton(top,text='Streamfunction contours',variable=self.psi,command=self.draw).pack(side='left',padx=8)
        ttk.Label(top,text='Δψ/(U∞D)').pack(side='left')
        x=ttk.Entry(top,textvariable=self.spacing,width=7);x.pack(side='left',padx=3);x.bind('<Return>',lambda e:self.draw())
        ttk.Checkbutton(top,text='Near-zero levels',variable=self.near,command=self.draw).pack(side='left',padx=5)
        ttk.Label(top,text='Vorticity:').pack(side='left',padx=(10,2))
        ttk.Combobox(top,textvariable=self.source,values=['velocity','solver'],state='readonly',width=9).pack(side='left')
        ttk.Checkbutton(top,text='Cylinder',variable=self.show_wall,command=self.draw).pack(side='left',padx=5)
        ttk.Button(top,text='Folder info',command=lambda:folder_information(root,[self.case.folder])).pack(side='right')
        nav=ttk.Frame(root,padding=5);nav.pack(fill='x')
        ttk.Button(nav,text='|<',command=lambda:self.set_frame(0)).pack(side='left')
        ttk.Button(nav,text='<',command=lambda:self.set_frame(self.i-1)).pack(side='left')
        self.play_button=ttk.Button(nav,text='Play',command=self.toggle_play);self.play_button.pack(side='left',padx=4)
        ttk.Button(nav,text='>',command=lambda:self.set_frame(self.i+1)).pack(side='left')
        ttk.Button(nav,text='>|',command=lambda:self.set_frame(len(self.case.frames)-1)).pack(side='left')
        self.slider=tk.Scale(nav,from_=0,to=len(self.case.frames)-1,orient='horizontal',showvalue=False,command=lambda v:self.set_frame(int(float(v)),from_slider=True))
        self.slider.pack(side='left',fill='x',expand=True,padx=15)
        ttk.Label(nav,text='FPS').pack(side='left');ttk.Entry(nav,textvariable=self.fps,width=5).pack(side='left',padx=3)
        self.status=ttk.Label(nav,text='');self.status.pack(side='left',padx=10)
        self.tabs=ttk.Notebook(root);self.tabs.pack(fill='both',expand=True)
        self.tabmap={}
        for name in ['Flow Field','L2 vs Time','Hydrodynamic Forces','Local Comparison','Tangential vs Radius','Radial Profiles','Particle Distribution','Line Profile']:
            f=ttk.Frame(self.tabs);self.tabs.add(f,text=name);self.tabmap[name]=f
        self.fig=Figure(figsize=(10,6),dpi=100)
        self.ax=self.fig.add_subplot(111)
        _,self.canvas=add_figure(self.tabmap['Flow Field'],self.fig)
        self.cid=self.canvas.mpl_connect('button_press_event',self.click_flow)
        self.aux={}
        for name in list(self.tabmap)[1:]:
            fig=Figure(figsize=(10,5),dpi=90)
            ax=fig.add_subplot(111)
            _,c=add_figure(self.tabmap[name],fig)
            self.aux[name]=(fig,ax,c)
        self.tabs.bind('<<NotebookTabChanged>>',lambda e:self.draw())
        self.field.trace_add('write',lambda *_:self.draw())
        self.profile_field.trace_add('write',lambda *_:self.draw())
        self._create_analysis_controls()
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.draw()

    def _create_analysis_controls(self):
        f=self.tabmap['Radial Profiles'];bar=ttk.Frame(f);bar.pack(fill='x',before=self.aux['Radial Profiles'][2].get_tk_widget())
        ttk.Label(bar,text='Angle (degrees)').pack(side='left',padx=5)
        ttk.Entry(bar,textvariable=self.profile_angle,width=10).pack(side='left')
        ttk.Label(bar,text='Variable').pack(side='left',padx=5)
        ttk.Combobox(bar,textvariable=self.profile_field,values=list(FIELD_NAMES),state='readonly',width=16).pack(side='left')
        ttk.Button(bar,text='Update',command=self.draw).pack(side='left',padx=5)
        f=self.tabmap['Line Profile'];bar=ttk.Frame(f);bar.pack(fill='x',before=self.aux['Line Profile'][2].get_tk_widget())
        self.line_label=ttk.Label(bar,text='Click “Pick A and B”, then click two points on Flow Field')
        self.line_label.pack(side='left',padx=6)
        ttk.Button(bar,text='Pick A and B',command=self.start_line).pack(side='left',padx=5)
        ttk.Button(bar,text='Clear',command=self.clear_line).pack(side='left')

    def start_line(self):
        self.line_points=[];self.line_active=True
        self.line_label.config(text='Click point A, then point B in Flow Field')
        self.tabs.select(self.tabmap['Flow Field'])
    def clear_line(self):self.line_points=[];self.line_active=False;self.draw()
    def click_flow(self,event):
        if not self.line_active or event.inaxes!=self.ax or event.xdata is None:return
        self.line_points.append((event.xdata,event.ydata))
        if len(self.line_points)==2:
            self.line_active=False;self.line_label.config(text='Line selected (updates with frame)')
            self.tabs.select(self.tabmap['Line Profile'])
        self.draw()
    def set_frame(self,i,from_slider=False):
        self.i=int(np.clip(i,0,len(self.case.frames)-1))
        if not from_slider:self.slider.set(self.i)
        self.draw()
    def toggle_play(self):
        self.playing=not self.playing
        self.play_button.config(text='Pause' if self.playing else 'Play')
        if self.playing:self.play_step()
        elif self.after_id is not None:self.root.after_cancel(self.after_id);self.after_id=None
    def play_step(self):
        if not self.playing:return
        if self.i>=len(self.case.frames)-1:self.playing=False;self.play_button.config(text='Play');return
        self.set_frame(self.i+1)
        try:delay=max(30,int(1000/float(self.fps.get())))
        except ValueError:delay=90
        self.after_id=self.root.after(delay,self.play_step)
    def close(self):
        self.playing=False
        if self.after_id is not None:self.root.after_cancel(self.after_id)
        self.root.destroy()

    def draw(self):
        if not hasattr(self,'canvas'):return
        field=self.field.get();case=self.case
        self.status.configure(text=f'Re {case.Re:g} | t={case.times[self.i]:.4g} s | {self.i+1}/{len(case.times)} | h/Δp={case.hdp:g}')
        current=self.tabs.tab(self.tabs.select(),'text')
        try:
            if current=='Flow Field':
                self.fig.clear();self.ax=self.fig.add_subplot(111)
                try:step=float(self.spacing.get())
                except ValueError:step=.06
                if field not in self.limits:self.limits[field]=case.initial_stats(field)
                m=draw_field(self.ax,case,self.i,field,self.psi.get(),step,self.near.get(),self.source.get(),self.limits[field],self.show_wall.get())
                self.fig.colorbar(m,ax=self.ax,label=FIELD_NAMES[field],fraction=.03,pad=.03)
                self.ax.set_title(f'{case.folder.name} | Re={case.Re:g} | t={case.times[self.i]:g} s')
                if self.line_points:
                    p=np.array(self.line_points);self.ax.plot(p[:,0],p[:,1],'o--',color='lime',lw=1.4)
                self.fig.tight_layout();self.canvas.draw_idle()
            else:
                fig,ax,canvas=self.aux[current];ax.clear()
                if current=='L2 vs Time':
                    L=case.summary_history()
                    for col,label in enumerate(['L2 velocity','L2 u','L2 v','L2 density']):
                        ax.semilogy(case.times,np.maximum(L[:,col],1e-30),label=label)
                    ax.axvline(case.times[self.i],color='black',ls='--');ax.legend(fontsize=9)
                    ax.set(xlabel='Time (s)',ylabel='C++ solver L2 values',title='Error/deviation reported by C++')
                elif current=='Hydrodynamic Forces':
                    df=case.global_forces()
                    if df is not None:
                        tcol='t' if 't' in df else df.columns[0]
                        for k in ['CDSPH','CLSPH','CDPressureSPH','CDViscousSPH']:
                            if k in df:ax.plot(df[tcol],df[k],label=k)
                        ax.axvline(case.times[self.i],c='black',ls='--');ax.legend()
                        ax.set(xlabel='Time (s)',ylabel='Force coefficient',title='Hydrodynamic forces (C++ output)')
                    else:ax.text(.5,.5,'PotentialFlowGlobalComparison CSV not found',ha='center',transform=ax.transAxes)
                elif current=='Local Comparison':
                    df=case.local_comparison()
                    if df is not None:
                        numeric_cols=[c for c in df if pd_is_numeric(df[c])]
                        if 't' in df and 'Angle' in df and len(numeric_cols)>2:
                            t=df['t'].iloc[(df['t']-case.times[self.i]).abs().argmin()]
                            ss=df[np.isclose(df['t'],t)]
                            variable='CpSPH' if 'CpSPH' in df else numeric_cols[-1]
                            ax.plot(ss['Angle'],ss[variable],'.-');ax.set(xlabel='Angle',ylabel=variable)
                        else:
                            ax.text(.5,.5,f'Local comparison available: {len(df)} rows\nColumns: {", ".join(df.columns[:7])}',ha='center',transform=ax.transAxes)
                    else:ax.text(.5,.5,'PotentialFlowLocalComparison CSV not found',ha='center',transform=ax.transAxes)
                elif current=='Tangential vs Radius':
                    d=case.read(self.i);u=case.polar(d['u'].to_numpy())/case.U;v=case.polar(d['v'].to_numpy())/case.U
                    for ang in [0,45,90,135,180]:
                        k=np.argmin(np.abs(np.angle(np.exp(1j*(case.theta-np.deg2rad(ang))))))
                        ut=-u[k]*np.sin(case.theta[k])+v[k]*np.cos(case.theta[k]);ax.plot(case.radii,np.abs(ut),label=f'{ang}°')
                    ax.set(xlabel='r/D',ylabel='|uθ|/U∞',title='Tangential speed vs radius');ax.legend()
                elif current=='Radial Profiles':
                    try:ang=float(self.profile_angle.get())
                    except ValueError:ang=90
                    k=np.argmin(np.abs(np.angle(np.exp(1j*(case.theta-np.deg2rad(ang))))))
                    z=case.polar(case.values(self.i,self.profile_field.get()))
                    ax.plot(case.radii,z[k],'.-');ax.set(xlabel='r/D',ylabel=FIELD_NAMES[self.profile_field.get()],title=f'Radial profile θ={ang:g}°')
                elif current=='Particle Distribution':
                    ax.scatter(case.x[case.fluid],case.y[case.fluid],s=1,alpha=.65)
                    ax.scatter(case.Xwall,case.Ywall,s=3,c='black');ax.set_aspect('equal')
                    ax.set(xlabel='x/D',ylabel='y/D',title='Physical SPH particle distribution')
                elif current=='Line Profile':
                    if len(self.line_points)<2:
                        ax.text(.5,.5,'Select two points on Flow Field to sample a line.',ha='center',transform=ax.transAxes)
                    else:
                        from scipy.interpolate import LinearNDInterpolator
                        A,B=np.asarray(self.line_points)
                        s=np.linspace(0,1,300);XY=A[None,:]+s[:,None]*(B-A)[None,:]
                        z=case.values(self.i,field)[case.fluid]
                        interp=LinearNDInterpolator(np.column_stack([case.x[case.fluid],case.y[case.fluid]]),z,fill_value=np.nan)
                        val=interp(XY)
                        inside=np.linalg.norm(XY,axis=1)<=case.wall_r;val[inside]=np.nan
                        ax.plot(s*np.linalg.norm(B-A),val)
                        ax.set(xlabel='Distance along A–B / D',ylabel=FIELD_NAMES[field],title='SPH field along selected line')
                ax.grid(alpha=.2);fig.tight_layout();canvas.draw_idle()
        except Exception as exc:
            messagebox.showerror('Plot error',f'{type(exc).__name__}: {exc}',parent=self.root)

def pd_is_numeric(series):
    import pandas as pd
    return pd.api.types.is_numeric_dtype(series)

def main():
    """Robust startup: make folder chooser visible and report errors."""
    import sys
    import traceback
    from tkinter import messagebox
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", nargs="?")
    args, _ = parser.parse_known_args()
    print("[EWCSPH] Starting viewer...", flush=True)
    root = None
    try:
        root = tk.Tk()
        root.title("EWCSPH - Choose simulation results")
        root.geometry("540x100")
        root.lift()
        root.attributes("-topmost", True)
        root.update()
        root.after(500, lambda: root.attributes("-topmost", False) if root.winfo_exists() else None)
        if args.folder:
            folder = args.folder
        else:
            print("[EWCSPH] Opening folder picker. Check Alt+Tab if necessary.", flush=True)
            folder = filedialog.askdirectory(parent=root, title="Select EWCSPH result folder", mustexist=True)
        if not folder:
            print("[EWCSPH] No folder selected; viewer closed.", flush=True)
            root.destroy()
            return
        print(f"[EWCSPH] Loading: {folder}", flush=True)
        root.deiconify()
        SingleViewer(root, folder)
        root.lift()
        root.mainloop()
    except Exception:
        details = traceback.format_exc()
        print("[EWCSPH] STARTUP ERROR:\n" + details, file=sys.stderr, flush=True)
        try:
            if root is not None and root.winfo_exists():
                root.deiconify()
                messagebox.showerror("EWCSPH startup error", details[-4500:], parent=root)
                root.destroy()
        except Exception:
            pass
        raise

if __name__ == "__main__":
    main()

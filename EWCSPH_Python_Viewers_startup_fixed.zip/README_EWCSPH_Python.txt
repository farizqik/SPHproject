EWCSPH Python Viewers — single-case and multi-case
===================================================

Files:
    ewcsph_core.py             Shared CSV reader and polar streamfunction Poisson solver
    ewcsph_gui.py              Common Tk/Matplotlib controls and multi-folder browser
    ewcsph_single_viewer.py    Single-case interactive viewer
    ewcsph_compare_viewer.py   Synchronized multiple-case comparison viewer
    requirements_ewcsph.txt    Python dependencies

Installation (Windows, Python 3.10+):
    py -m pip install -r requirements_ewcsph.txt

Run from the same directory containing all .py files:
    py ewcsph_single_viewer.py
    py ewcsph_compare_viewer.py

Alternatively, supply simulation folders directly:
    py ewcsph_single_viewer.py "C:\\my-results\\Case1"
    py ewcsph_compare_viewer.py "C:\\my-results\\Case1" "D:\\results\\Case2"

Comparison folder selection:
    The multi-folder browser opens DIRECTLY. Ctrl/Shift to highlight multiple
    [RESULT] folders. 'Add selected' queues those directories. You can navigate
    to another directory and add more before clicking 'Use selected / added folders'.
    Double-click a folder to navigate inside; click Up to navigate upward.

Input files (read from C++ outputs, no resimulation):
    SimulationConstants.csv
    EWCSPH_hdp_<value>_t_<time>.csv
    PotentialFlowGlobalComparison_hdp_<value>.csv (optional)
    PotentialFlowLocalComparison_hdp_<value>.csv (optional)

Plot settings:
    Field: selects nondimensional velocity, pressure, vorticity etc.
    Streamfunction contours: Δψ/(U∞D), default 0.06. Use 0.015 for denser contours.
    Near-zero levels: finer global levels around ψ=0 (not cropped downstream).
    Vorticity source: 'velocity' computes curl from SPH u/v, while 'solver'
        uses saved CSV vorticity.

Notes:
    Streamfunction ψ is a solenoidal reconstruction of the weakly compressible
    EWCSPH velocity, NOT the exact trajectory field. Reconstruction uses the
    cylinder boundary ψ=0 and outer flux recovered from saved SPH radial velocity.
    Mesh and solver numerical fidelity should be validated for each physical case.
    The first h/Δp found in each folder is loaded by default. To compare another
    h/Δp, adjust the Case(..., hdp=...) instantiation in the Python script.
    MP4 export uses ffmpeg (separately installed and accessible on PATH).
    Both viewers are independent Python interfaces, not line-for-line MATLAB ports.
    The MATLAB viewer has additional specialised plots and callbacks; the Python
    version covers primary interactive flow/streamfunction features, common
    diagnostics, folder information and exports, but is not feature-parity yet.
